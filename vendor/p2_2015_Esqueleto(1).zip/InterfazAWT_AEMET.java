import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Date;
import java.text.SimpleDateFormat;

/**
 * Fichero: InterfazAWT_AEMET.java
 * Clase que implementa la Interfaz Gr�fica AEMET con awt.
 * @author  PAA
 * @version 1.0
 */
public class InterfazAWT_AEMET extends Frame {
	private static final String FICHERO = "almacen.dat"; 
	
	private MenuBar barraDeMenu;
	
//	private IAlmacenPoblaciones almacenPoblaciones;
//	private List listaPoblaciones;
//	private List listaPredicciones;
	
	/**
	 * Constructor.
	 */
	public InterfazAWT_AEMET(String titulo, int ancho, int alto){
		super(titulo);
		setSize(ancho,alto);
		setLocationRelativeTo(null);
		setLayout( new BorderLayout() ); // Layout de la aplicaci�n, podr�a ser otro

		// Recuperamos el almac�n
		// almacenAlbumes = new AlmacenAlbumes();
		// if (almacenAlbumes.recuperar(FICHERO))
		//	System.out.println("Recuperado el almacen del fichero " + FICHERO);
		//else 
		//	System.out.println("No se pudo recuperar el almacen del fichero " + FICHERO);
	
		//Sit�o los men�s desplegables
		barraDeMenu = new MenuBar();
		setMenuBar(barraDeMenu);
		
		// Creo el men� Archivo
		
		// Creo el men� Provincias
		Menu menuProvincias = new Menu("Provincias");
		MenuItem crearProvincias = new MenuItem ("Crear provincia");
		crearProvincias.addActionListener(new CrearProvincia());
		menuProvincias.add(crearProvincias);
		
		// A�adir m�s elementos de menu
		
		barraDeMenu.add(menuProvincias);

		// A�adir m�s men�s
		// ::::::::::
		
		// Creo el men� de ayuda
		Menu ayuda = new Menu("Ayuda");
		MenuItem acercaDe = new MenuItem("Acerca de");
		acercaDe.addActionListener(new AcercaDe());
		ayuda.add(acercaDe);

		// Sit�o el men� de ayuda en su sitio
		barraDeMenu.setHelpMenu(ayuda);		

		//Sit�o la l�nea de botones
		Panel lineaDeBotones = new Panel();
		lineaDeBotones.setLayout (new FlowLayout (FlowLayout.LEFT));

		// Crear botones
		// Definir listeners
		// A�adir al panel

		Button bcrear = new Button("Crear Provincia");
		bcrear.addActionListener(new CrearProvincia());
		lineaDeBotones.add(bcrear);
		
		// A�adir el panel al layout general
		add (lineaDeBotones,BorderLayout.NORTH);


		//Sit�o la l�nea de estado
		Panel lineaDeEstado = new Panel();
		lineaDeEstado.setLayout (new FlowLayout (FlowLayout.LEFT));
		lineaDeEstado.setBackground (Color.lightGray);
		Label ventanaDeeventos = new Label("Gestor AEMET v1.0 (PAA)");
		lineaDeEstado.add (ventanaDeeventos);
		add (lineaDeEstado, BorderLayout.SOUTH);

		// Definir los panels de la lista de predicciones
		// Definir listeners de cada uno de los elementos
		// A�adir al layout de la aplicaci�n
		
		

		addWindowListener (new WindowAdapter () { 
	          public void windowClosing(WindowEvent e) { 
	        	  guardarAntesDeSalir ();
	              System.exit(0); 
	             } 
	    });
	}//Constructor
	
	private void guardarAntesDeSalir () {

		// Guardar almacen		
		System.out.println ("Gracias por utilizar nuestro programa");
	}

	
	/**
	 * Clase que implementa la acci�n del men� "acerca de".
	 */
	class AcercaDe implements ActionListener{  // Clase interna
		public void actionPerformed(ActionEvent e){
			VentanaAcercaDe ventanaAcercaDe = new VentanaAcercaDe(InterfazAWT_AEMET.this);
			ventanaAcercaDe.setVisible(true);
		}
	}//Acerca de
	

	class CrearProvincia implements ActionListener {
		  public void actionPerformed(ActionEvent e) {
			// Codificar una clase propia para a�adir una provincia
			Aviso aviso = new Aviso(InterfazAWT_AEMET.this, "Ventana de Crear Provincias");
			aviso.setVisible(true);
		  } 
	}

	/**
	 * M�todo main.
	 */
	public static void main(String[] args) {
		
		InterfazAWT_AEMET mimarco = new InterfazAWT_AEMET("Gestor AEMET",1000,500);
		mimarco.setVisible(true);
	} // Main
}
